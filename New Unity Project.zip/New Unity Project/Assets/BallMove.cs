﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BallMove : MonoBehaviour
{
    public Rigidbody rb;
    public float xThrust;
    public float yThrust;
    public float speed;
    public GameObject pongBall;

    void Start()
    {
        yThrust = Random.Range(-15f, 15f);
        rb = GetComponent<Rigidbody>();
        rb.AddForce(xThrust, yThrust, 0, ForceMode.Impulse);
    }

    void FixedUpdate()
    {
        rb.velocity = speed * (rb.velocity.normalized);
    }

    void OnCollisionEnter(Collision collider)
    { 
        if (collider.collider.gameObject.name == "RightPlayerWall")
        {
            Instantiate(pongBall, new Vector3(0, 5, 0), Quaternion.identity);
            Destroy(gameObject);
        }
        if (collider.collider.gameObject.name == "LeftPlayerWall")
        {
            Instantiate(pongBall, new Vector3(0, 5, 0), Quaternion.identity);
            Destroy(gameObject);
        }
    }
}
